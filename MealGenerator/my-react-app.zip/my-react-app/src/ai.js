﻿export const AI_CONFIG = {
    BATCH_THRESHOLD: 3,  // Minimum items to trigger batch processing
    SUMMARY_MAX_WORDS: 30,
    VALIDATION_TIMEOUT: 3000 // ms
};